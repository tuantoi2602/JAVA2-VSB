## Log4j2
- File config: src/main/resources/log4j2.xml