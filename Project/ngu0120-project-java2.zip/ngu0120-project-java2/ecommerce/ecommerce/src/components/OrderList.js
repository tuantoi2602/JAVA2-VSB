import React, { useState, useEffect } from "react";
import { Container, Table } from "react-bootstrap";
import axios from "axios";

function OrderList(props) {
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState([]);
  const [messages, setMessages] = useState({});

  useEffect(() => {
    axios.get(`http://localhost:8080/message?language=${props.language}`)
      .then(response => setMessages(response.data))
      .catch(error => console.error(error));
  }, [props.language]);
  
  useEffect(() => {
    axios
      .get("http://localhost:8080/orders")
      .then((response) => {
        setOrders(response.data);
      })
      .catch((error) => {
        console.log(error);
      });

    axios
      .get("http://localhost:8080/products")
      .then((response) => {
        setProducts(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);
  const handleDeleteOrder = async (orderId) => {
    try {
      await axios.delete(`http://localhost:8080/orders/${orderId}`);
      setOrders(orders.filter((order) => order.id !== orderId));
    } catch (error) {
      console.log(error);
    }
  };
  const handleAddProductToOrder = async (orderId, productId) => {
    try {
      const order = orders.find((order) => order.id === orderId);
      const product = products.find((product) => product.id === productId);
      const updatedOrder = { ...order, productId, price: product.price };
      await axios.put(`http://localhost:8080/orders/${orderId}`, updatedOrder);
      setOrders(orders.map((order) => (order.id === orderId ? updatedOrder : order)));
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>ID</th>
          <th>
            {messages.order_name}
          </th>
          <th>
            {messages.order_date}

          </th>
          <th>
            {messages.order_amount}

          </th>
          <th>
            {messages.order_price}

          </th>
          <th>
            {messages.delete}

          </th>
          
        </tr>
      </thead>
      <tbody>
        {orders.map((order) => (
          <tr key={order.id}>
            <td>{order.id}</td>
            <td>{products.find(product => product.id === order.productId)?.name}</td>
            <td>{order.orderDate}</td>
            <td>{order.quantity}</td>
            <td>{products.find(product => product.id === order.productId)?.price * order.quantity}$</td>
            <td>
              <button onClick={() => handleDeleteOrder(order.id)}>
                {messages.product_delete}

              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
}

export default OrderList;
