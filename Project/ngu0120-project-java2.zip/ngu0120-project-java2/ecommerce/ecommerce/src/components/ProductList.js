import React, { useState, useEffect } from "react";
import { Row, Col, Card, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import axios from "axios";
import AddProductForm from './AddProductForm';
import EditProductForm from './EditProductForm';


function ProductList(props) {
  const [products, setProducts] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [messages, setMessages] = useState({});

  useEffect(() => {
    axios.get(`http://localhost:8080/message?language=${props.language}`)
      .then(response => setMessages(response.data))
      .catch(error => console.error(error));
  }, [props.language]);

  useEffect(() => {
    axios
      .get("http://localhost:8080/products")
      .then((response) => {
        console.log(response);
        setProducts(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  
  }, []);

  const handleDelete = (id) => {
    axios
      .delete(`http://localhost:8080/products/${id}`)
      .then(() => {
        setProducts(products.filter((product) => product.id !== id));
      })
      .catch((error) => {
        console.log(error);
      });
  };
  const handleBuy = (productId, productName, productPrice) => {
    const order = {
      productId: productId,
      productName: productName,
      productPrice: productPrice,
      quantity: 3,
      orderDate: new Date()
    };
  
    fetch('http://localhost:8080/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(order)
    })
    .then(response => response.json())
    .then(data => {
      console.log('Order created:', data);
      // Do something with the newly created order
    })
    .catch(error => {
      console.error('Error creating order:', error);
    });
  }
  
  const handleEdit = (id) => {
    axios
      .get(`http://localhost:8080/products/${id}`)
      .then((response) => {
        setSelectedProduct(response.data);
        setShowEditForm(true);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleAddProduct = (product) => {
    axios
      .post("http://localhost:8080/products", product)
      .then((response) => {
        setProducts([...products, response.data]);
        setShowAddForm(false);
      })
      .catch((error) => {
        console.log(error);
      });
  };
  const handleToggleEditForm = () => {
    setShowEditForm((prevValue) => !prevValue);
  };
  const handleToggleAddForm = () => {
    setShowAddForm(!showAddForm);
  };
  const handleUpdateProduct = (id, updatedProduct) => {
    axios
      .put(`http://localhost:8080/products/${id}`, updatedProduct)
      .then((response) => {
        const updatedProducts = products.map((product) =>
          product.id === id ? response.data : product
        );
        setProducts(updatedProducts);
        setSelectedProduct(null);
        setShowEditForm(false);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div>
     {showAddForm ? (
        <AddProductForm onAddProduct={handleAddProduct} language={props.language}/>
      ) : (
        <Button variant="success" onClick={handleToggleAddForm}>
        {messages.add_addproduct}

        </Button>
      )}
      {showEditForm && (
        <EditProductForm
          product={selectedProduct}
          onUpdateProduct={handleUpdateProduct}
          onToggleEditForm={handleToggleEditForm}
          language={props.language}
        />
      )}
    <Row>
      {products.map((product) => (
        <Col md={4} key={product.id}>
          <Card className="mb-4">
            <Card.Img
              variant="top"
              src={
                "https://goldbelly.imgix.net/uploads/showcase_media_asset/image/79619/joes-kc-ribs-brisket-and-burnt-ends.6710e994980e485e6441b794717ad6fb.jpg?ixlib=react-9.0.2&auto=format&ar=1%3A1"
              }
            />
            <Card.Body>
              <Card.Title>{product.name}</Card.Title>
              <Card.Text>{product.description}</Card.Text>
              <Card.Text>{product.price}$</Card.Text>
              <Button as={Link} to={`/products/${product.id}`} variant="primary">
                {messages.product_view}

              </Button>
              <Button
                  variant="primary"
                  onClick={() => handleBuy(product.id, product.name, product.price)}
                >
                {messages.product_buy}

                </Button>

              <Button variant="danger" onClick={() => handleDelete(product.id)}>
                {messages.product_delete}

              </Button>
                <Button
                  variant="warning"
                  className="mx-2"
                  onClick={() => handleEdit(product.id)}
                >
                {messages.product_edit}
                </Button>
            </Card.Body>
          </Card>
        </Col>
      ))}
    </Row>
    </div>
  );
}

export default ProductList;
