import React, { useState, useEffect } from "react";
import { Form, Button } from "react-bootstrap";
import { FormattedMessage } from "react-intl";
import { useIntl } from 'react-intl';
import axios from "axios";


function AddProductForm({ onAddProduct,language }, props) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const intl = useIntl();
  const [messages, setMessages] = useState(props);


  useEffect(() => {
    axios
      .get(`http://localhost:8080/message?language=${language}`)
      .then(response => setMessages(response.data))
      .catch(error => console.error(error));
  }, [language]);
  

  const handleSubmit = (event) => {
    event.preventDefault();
    const product = { name, description, price };
    onAddProduct(product);
    setName("");
    setDescription("");
    setPrice("");
  };

  return (
    <Form onSubmit={handleSubmit}>
      <Form.Group controlId="formBasicName">
        <Form.Label>
        {messages.add_name}

        </Form.Label>
        <Form.Control
          type="text"
          placeholder={messages.add_product_name}

          value={name}
          onChange={(event) => setName(event.target.value)}
        />
      </Form.Group>

      <Form.Group controlId="formBasicDescription">
        <Form.Label>
        {messages.add_description}


        </Form.Label>
        <Form.Control
          as="textarea"
          rows={3}
          placeholder={messages.add_product_description}

          value={description}
          onChange={(event) => setDescription(event.target.value)}
        />
      </Form.Group>

      <Form.Group controlId="formBasicPrice">
        <Form.Label>
        {messages.add_price}

        </Form.Label>
        <Form.Control
          type="number"
          placeholder={messages.add_product_price}

          value={price}
          onChange={(event) => setPrice(event.target.value)}
        />
      </Form.Group>

      <Button variant="primary" type="submit">
      {messages.add_addproduct}

      </Button>
    </Form>
  );
}

export default AddProductForm;
