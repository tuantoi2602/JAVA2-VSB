package ngu0120.language;

import java.time.LocalDate;
import java.util.Locale;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
public class Hello {

    private static final Logger logger = LogManager.getLogger(Hello.class);


    

    public static void main(String[] args) {
    	
        logger.debug("Debug message");
        logger.info("Info message");
        logger.warn("Warn message");
        logger.error("Error message");
        logger.fatal("Fatal message");
    	
    	
        LocalDate date = LocalDate.of(2023, 5, 1);
        long days = DayCalculator.daysBetweenTodayAndDate(date);
        System.out.println("Days between today and " + date.toString() + ": " + days);
        logger.info("Days between today: " + days);

        
        
        Locale locale = null;
        if (args.length > 0) {
            locale = new Locale(args[0]);
        } else {
            locale = Locale.getDefault();
        }

        ResourceBundle messages = ResourceBundle.getBundle("MessagesBundle", locale);
        logger.debug("Selected locale: " + locale.toString());
        logger.info("Greeting message: " + messages);
        System.out.println(messages.getString("hello"));
        ResourceBundle messages_fr = ResourceBundle.getBundle("MessagesBundle_fr_FR", locale);
        System.out.println(messages_fr.getString("hello"));
        logger.debug("Selected locale: " + locale.toString());
        logger.info("Greeting message: " + messages_fr);
        ResourceBundle messages_cs = ResourceBundle.getBundle("MessagesBundle_cs_CZ", locale);
        System.out.println(messages_cs.getString("hello"));
        logger.debug("Selected locale: " + locale.toString());
        logger.info("Greeting message: " + messages_cs);
        ResourceBundle messages_es = ResourceBundle.getBundle("MessagesBundle_es_SP", locale);
        System.out.println(messages_es.getString("hello"));
        logger.debug("Selected locale: " + locale.toString());
        logger.info("Greeting message: " + messages_es);

    }
}

