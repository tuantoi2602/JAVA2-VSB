package ngu0120.language;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class DayCalculator {

    public static long daysBetweenTodayAndDate(LocalDate date) {
        LocalDate today = LocalDate.now();
        return ChronoUnit.DAYS.between(today, date);
    }

}
