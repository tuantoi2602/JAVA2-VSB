CREATE TABLE homework.Car (
    id BIGINT NOT NULL AUTO_INCREMENT,
    color VARCHAR(50),
    weight INT,
    max_speed INT,
    rz VARCHAR(50),
    brand VARCHAR(50),
    type VARCHAR(50),
    PRIMARY KEY (id)
);
INSERT INTO homework.Car (color, weight, max_speed, rz, brand, type)
VALUES ('red', 1500, 200, 'RZ1', 'Toyota', 'SUV');
