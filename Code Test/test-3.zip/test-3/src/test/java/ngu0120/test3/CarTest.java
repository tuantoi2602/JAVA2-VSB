package ngu0120.test3;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import io.quarkus.test.junit.QuarkusTest;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


@QuarkusTest
@ApplicationScoped
public class CarTest {

    public static void main(String[] args) {
    	
        
    	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("test3");
   
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        // create a new Car instance and set its attributes
        Car car = new Car.Builder()
                .color("Red")
                .weight(1500)
                .maxSpeed(200)
                .rz("ABC123")
                .brand("Tesla")
                .type("Electric")
                .build();

        // persist the Car instance to the database
        entityManager.getTransaction().begin();
        entityManager.persist(car);
        entityManager.getTransaction().commit();

        entityManager.close();
        entityManagerFactory.close();
    }
}

